# Deskripsi Aplikasi
 Sistem Informasi Perpustakaan Berbasis Web merupakan sistem yang dapat digunakan untuk mengelola berbagai aktifitas di perpustakaan, mulai dari penyimpanan databuku hingga proses peminjaman.

# Framework
* Codeigniter 3.1.11
* Template Admin LTE  Versi 2.4

# Penggunaan Login Akses

<b>Petugas Perpus : </b>
<br/>
User : anang
<br/>
Pass : 123

<b>Anggota Perpus :</b>
<br/>
User : fauzan
<br/>
Pass : 123

# Contributors
<a href="https://fauzan.codekop.com/"> Fauzan Falah</a>

My Blog : <a href="https://www.codekop.com/"> Codekop.com</a>

Gunakan Aplikasi dengan bijak, dan selamat belajar